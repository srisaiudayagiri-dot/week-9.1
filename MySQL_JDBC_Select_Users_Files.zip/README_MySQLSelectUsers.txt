MySQL JDBC SELECT Users — Java files

Files:
- MySQLSelectUsers.java: connects to mydatabase and prints id, username, email.
- README_MySQLSelectUsers.txt: setup instructions.

Before running:
1. Start your MySQL server.
2. Create database `mydatabase` and table `users` with columns `id`, `username`, and `email`.
3. Edit MySQLSelectUsers.java and replace USERNAME/PASSWORD with your MySQL credentials.
4. Download MySQL Connector/J and include it on the classpath.

Example database setup:
CREATE DATABASE mydatabase;
USE mydatabase;

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL
);

Example records:
INSERT INTO users (username, email) VALUES
('johndoe', 'johndoe@example.com'),
('janedoe', 'janedoe@example.com'),
('alice', 'alice@example.com');

Compile and run (Linux/macOS; use : as the classpath separator):
javac -cp "mysql-connector-j-<version>.jar" MySQLSelectUsers.java
java -cp ".:mysql-connector-j-<version>.jar" MySQLSelectUsers

Windows Command Prompt (uses ; as the classpath separator):
javac -cp "mysql-connector-j-<version>.jar" MySQLSelectUsers.java
java -cp ".;mysql-connector-j-<version>.jar" MySQLSelectUsers

Replace <version> with the version in your downloaded Connector/J filename.
